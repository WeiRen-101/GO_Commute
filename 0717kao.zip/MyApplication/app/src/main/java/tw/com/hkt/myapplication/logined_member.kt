package tw.com.hkt.myapplication

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.android.gms.common.internal.FallbackServiceBroker
import tw.com.hkt.myapplication.databinding.ActivityLoginedMemberBinding

class logined_member : AppCompatActivity() {
    private lateinit var binding: ActivityLoginedMemberBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityLoginedMemberBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val sharedPref = getSharedPreferences("user_prefs", Context.MODE_PRIVATE)
        val isLoggedIn = sharedPref.getBoolean("is_logged_in", false)
        val editor = sharedPref.edit()  //改寫器

        //登出帳號
        binding.button34.setOnClickListener {
            editor.putBoolean("is_logged_in", false)    //狀態登出
            editor.apply()
            finish()
            val intent = Intent(this, MainActivity::class.java)
            startActivity(intent)

            //測試用
            //Toast.makeText(this, "isLoggedIn1: $isLoggedIn", Toast.LENGTH_SHORT).show()
        }


        binding.button26.setOnClickListener {
            val intent = Intent(this,
                setting::class.java)
            startActivity(intent)
        }
        binding.imageButton.setOnClickListener {
            finish()
            val intent = Intent(this, MainActivity::class.java)
            startActivity(intent)

        }
    }
}
