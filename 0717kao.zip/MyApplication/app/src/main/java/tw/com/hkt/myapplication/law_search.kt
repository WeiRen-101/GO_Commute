package tw.com.hkt.myapplication

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import tw.com.hkt.myapplication.databinding.ActivityLawSearchBinding
import tw.com.hkt.myapplication.databinding.ActivityRegisterBinding

class law_search : AppCompatActivity() {
    private lateinit var binding: ActivityLawSearchBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityLawSearchBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // 返回按鈕的點擊事件
        binding.imageButton.setOnClickListener { //倒退
            finish()
        }

        // 法規查詢按鈕的點擊事件
        binding.imageButton2.setOnClickListener {    //總體法規查詢(暫)
            // 創建意圖來啟動 GridViewActivity
            val intent = Intent(this, GridViewActivity::class.java)
            startActivity(intent)
        }
    }
}

