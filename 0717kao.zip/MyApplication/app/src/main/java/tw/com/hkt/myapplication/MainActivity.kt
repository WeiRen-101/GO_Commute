package tw.com.hkt.myapplication

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import tw.com.hkt.myapplication.databinding.ActivityMainBinding
import tw.com.hkt.myapplication.databinding.ActivityMapsWarningBinding

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private val TABLE_NAME = "SystemAccount"
    private lateinit var register: register
    private lateinit var login: login

    private lateinit var edEmail: EditText
    private lateinit var edPassword: EditText
    private lateinit var btLogin: Button
    private lateinit var btRegister: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.button13.setOnClickListener { //交通資訊
            val intent = Intent(this, traffic_information::class.java)
            startActivity(intent)
        }
        binding.imageButton.setOnClickListener{ //會員頁面
            val intent = Intent(this, member::class.java)
            startActivity(intent)
        }
        binding.button15.setOnClickListener {   //導航
            val intent = Intent(this, MyLocationActivity::class.java)
            startActivity(intent)
        }
        binding.button14.setOnClickListener {   //警示
            val intent = Intent(this, MapsWarning::class.java)
            startActivity(intent)
        }

    }
}
