package tw.com.hkt.myapplication

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.core.content.ContextCompat.startActivity
import tw.com.hkt.myapplication.databinding.ActivityMainBinding
import tw.com.hkt.myapplication.databinding.ActivityTrafficInformationBinding

class traffic_information : AppCompatActivity() {
    private lateinit var binding: ActivityTrafficInformationBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityTrafficInformationBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.button24.setOnClickListener {   //交通資訊總則
            val intent = Intent(this, traffic_law_all::class.java)
            startActivity(intent)
        }
        binding.button11.setOnClickListener {   //法規查詢
            val intent = Intent(this, law_search::class.java)
            startActivity(intent)
        }
        binding.button10.setOnClickListener {   //統計圖表
            val intent = Intent(this, statistic::class.java)
            startActivity(intent)
        }
        binding.imageButton.setOnClickListener { //退回主頁
            finish()
        }

    }
}