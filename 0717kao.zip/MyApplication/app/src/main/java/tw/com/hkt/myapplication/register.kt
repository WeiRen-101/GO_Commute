package tw.com.hkt.myapplication

import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.os.Bundle
import android.util.Base64
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import tw.com.hkt.myapplication.databinding.ActivityRegisterBinding
import java.nio.charset.StandardCharsets
import java.security.MessageDigest
import java.security.NoSuchAlgorithmException
import java.security.SecureRandom

class register : AppCompatActivity() {

    var loginF: Boolean = false //LoginFlag確認是否已登入

    private lateinit var binding: ActivityRegisterBinding
    private lateinit var dbHelper: DatabaseHelper

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityRegisterBinding.inflate(layoutInflater)
        setContentView(binding.root)

        dbHelper = DatabaseHelper(this, "SystemAccount")

        binding.imageButton.setOnClickListener {    //退出
            finish()
        }
        binding.button38.setOnClickListener {   //登入
            finish()
            val intent = Intent(this, login::class.java)
            startActivity(intent)
        }

        binding.button16.setOnClickListener {   //註冊
            val email = binding.editTextText.text.toString()
            val password = binding.editTextTextPassword2.text.toString()
            val confirmPassword = binding.editTextTextPassword.text.toString()

            if (password == confirmPassword) {
                if (register(email, password)) {
                    Toast.makeText(this, "註冊成功", Toast.LENGTH_SHORT).show()
                    loginF = true               //已登入
                    finish()
                    val intent = Intent(this, member::class.java)
                    startActivity(intent)       //跳回會員介面

                } else {
                    Toast.makeText(this, "註冊失敗", Toast.LENGTH_SHORT).show()
                }
            } else {
                Toast.makeText(this, "密碼不一致", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun register(email: String, password: String): Boolean {
        val db = dbHelper.writableDatabase

        val salt = generateSalt()
        val hashedPassword = hashPassword(password, salt)

        val values = ContentValues().apply {
            put("Email", email)
            put("PasswordSalt", salt)
            put("PasswordHash", hashedPassword)
        }

        val result = db.insert("SystemAccount", null, values)
        return result != -1L
    }

    private fun hashPassword(password: String, salt: String): String? {
        return try {
            val digest = MessageDigest.getInstance("SHA-256")
            val source = password.toByteArray(StandardCharsets.UTF_8)
            val saltBytes = Base64.decode(salt, Base64.DEFAULT)
            val passAndSalt = concatenateByteArrays(source, saltBytes)
            val hash = digest.digest(passAndSalt)
            Base64.encodeToString(hash, Base64.DEFAULT).trim()
        } catch (e: NoSuchAlgorithmException) {
            e.printStackTrace()
            null
        }
    }

    private fun generateSalt(): String {
        val random = SecureRandom()
        val salt = ByteArray(16)
        random.nextBytes(salt)
        return Base64.encodeToString(salt, Base64.DEFAULT).trim()
    }

    private fun concatenateByteArrays(a: ByteArray, b: ByteArray): ByteArray {
        return ByteArray(a.size + b.size).apply {
            System.arraycopy(a, 0, this, 0, a.size)
            System.arraycopy(b, 0, this, a.size, b.size)
        }
    }

    private class DatabaseHelper(context: Context, val tableName: String) : SQLiteOpenHelper(context, DATABASE_NAME, null, DATABASE_VERSION) {
        override fun onCreate(db: SQLiteDatabase) {
            db.execSQL("CREATE TABLE IF NOT EXISTS $tableName (" +
                    "BusinessEntityID INTEGER PRIMARY KEY AUTOINCREMENT," +
                    "Email TEXT UNIQUE," +
                    "PasswordSalt TEXT," +
                    "PasswordHash TEXT)")
        }

        override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
            db.execSQL("DROP TABLE IF EXISTS $tableName")
            onCreate(db)
        }

        companion object {
            private const val DATABASE_NAME = "memberDB"
            private const val DATABASE_VERSION = 1
        }
    }
}
